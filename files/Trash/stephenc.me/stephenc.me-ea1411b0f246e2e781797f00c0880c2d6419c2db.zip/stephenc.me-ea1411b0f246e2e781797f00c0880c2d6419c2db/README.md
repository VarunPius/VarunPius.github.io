I'm Stephen Chen, a developer and designer based in Los Angeles, CA. http://stephenc.me/
